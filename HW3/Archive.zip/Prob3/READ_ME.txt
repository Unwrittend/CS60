compile with:
g++ main.cpp billing.cpp billing.h doctor.h doctor.cpp employee.cpp employee.h patient.h patient.cpp person.cpp person.h salariedemployee.cpp salariedemployee.h
to change results modify the values in the constructors
