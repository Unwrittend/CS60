Compile with:
g++ salariedemployee.cpp salariedemployee.h employee.cpp employee.h main.cpp doctor.h doctor.cpp
edit the outputs by changing the values in the constructors
