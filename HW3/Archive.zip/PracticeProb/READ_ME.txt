Instructions:
1. Compile everything using
  g++ Administrator.cpp Administrator.h salariedemployee.cpp salariedemployee.h employee.cpp employee.h main.cpp
2. run program
